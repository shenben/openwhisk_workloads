import os
print(os.getcwd())
def ok():
    return 99